<?php
$db= new PDO('mysql:host=localhost;dbname=elec_db;charset=utf8',"root","");
$error = "";
?>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
    <link rel="stylesheet" href="../css/styl.css" type="text/css">
    <title> - Analyse Datalayer - </title>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script type="text/javascript" src="app.js"></script>

  </head>

<body>
    <div id="old_cont">
        <div id="menu_container">
            <ul id="menu">
                <li><a class="active" href="index.php"> - Comparateur Datalayer / Scrap - </a></li>
                <li><a class="active" href="vizualisation.php"> - Analyse Datalayer - </a></li>
                <li><a class="active" href="product_finder.php"> - Recherche de produit - </a></li>
            </ul>
        </div>
    </div>

    <div class="container_item content_panel">
        <div class="select_key_datalayer">
            <label for="datalayer_select">Choississez une feature de produit</label>
            <form id="datalayer_selector" method="post"> 
                <select name="search" id="datalayer_select">
                    <?php
                        $fetch_features = $db -> query("SELECT DISTINCT feature_type FROM features ORDER BY feature_type");
                        echo $fetch_features -> fetch();
                        while($feature_type = $fetch_features -> fetch()){
                            echo $feature_type[0];
                            ?>

                            <option value=<?php $feature_type[0];?>><?php echo $feature_type[0];?></option>
                            
                        <?php
                        }
                        ?>

                </select>
            </form>

            <label for="datalayer_select">Choississez une categorie de produit</label>
            <form id="datalayer_selector" method="post"> 
                <select name="search" id="datalayer_select">
                    <?php
                        $fetch_features = $db -> query("SELECT DISTINCT pageSubCategory_2 FROM products ORDER BY pageSubCategory_2");
                        echo $fetch_features -> fetch();
                        while($feature_type = $fetch_features -> fetch()){
                            echo $feature_type[0];
                            ?>

                            <option value=<?php $feature_type[0];?>><?php echo $feature_type[0];?></option>
                            
                        <?php
                        }
                        ?>

                </select>
            </form>
        </div>
    </div>


</body>

</html>
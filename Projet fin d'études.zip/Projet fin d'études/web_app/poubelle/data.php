<?php

    $db= new PDO('mysql:host=localhost;dbname=Electrodepot_db;charset=utf8',"test","Test123456-+!");
    $error = "";

    $rs = $db->query('SELECT * FROM products');
    $obj = $rs->fetchAll();
    $data = array();
    foreach ($obj as $row){
        $data[] = $row;
        }
        #print json_encode($data)
?>
<?php
$db= new PDO('mysql:host=localhost;dbname=Electrodepot_db;charset=utf8',"test","Test123456-+!");
$error = "";
?>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Comparateur datalayer // scrap</title>
    <link rel="stylesheet" href="style.css">
</head>


<body>
    <button class="accordion"> Good item
        <div class="good_item panel">
            <?php
            $fetching_matching_products = $db -> query('SELECT * FROM products INNER JOIN datalayers ON(products.ID = datalayers.ID) WHERE products.variant = datalayers.variant');
            while($products = $fetching_matching_products -> fetch()){
            ?>
                <div id="product_name"><?php echo $products['URL'];?><div>
            <?php
            }?>
        </div>
    </button>
    <button class="accordion"> Wrong item
        <div class="wrong_item panel">
            <?php
            $fetching_notmatching_products = $db -> query('SELECT * FROM products INNER JOIN datalayers ON(products.ID = datalayers.ID) WHERE products.variant != datalayers.variant');
            while($wrong_products = $fetching_notmatching_products -> fetch()){
            ?>
                <div id="product_name"><?php echo $wrong_products['URL'];?><div>
                <?php
                }?>
        </div>
    </button>
</body>

<script>
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active");

        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
        panel.style.display = "none";
        } else {
        panel.style.display = "block";
        }
    });
    }
</script>



</html>




 <!-- <div class="container_item content_panel">
         <div id='vis'>
            <table>
            <?php
                  $issue = $db -> query('SELECT products.ID,URL,products.name FROM products INNER JOIN datalayers ON (products.ID = datalayers.ID) WHERE products.name != datalayers.name OR products.price != datalayers.price OR products.brand != datalayers.brand OR products.category != datalayers.category OR products.reduction != datalayers.reduction');
                  while($fr = $issue -> fetch()){?>
               <tr>
                  <?php echo '<td><a class="active_p" href= ',$fr["URL"],'>Lien du produit</a></td>'?>
                  <td><?php echo $fr["ID"]?></td>
                  <td><?php echo $fr["name"]?></td>
               </tr>
               <?php
                  }
                  ?>
            </table>
         </div>
      </div> -->
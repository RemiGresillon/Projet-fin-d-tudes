<script>
     var xhr = new XMLHttpRequest();
     function reload(){
       xhr.onreadystatechange = function(){
         var DONE = 4;
         var OK = 200;
         if (xhr.readyState === DONE){
           if (xhr.status === OK){
             console.log("ok");
            <?php $Vizualisation_rating =  $_GET["search"]; ?>;
            } else{console.log("ERROR");}
           }
         }
       }
     setInterval(reload,100);


   </script>
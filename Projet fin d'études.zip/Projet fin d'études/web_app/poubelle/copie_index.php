<?php
$db= new PDO('mysql:host=localhost;dbname=Electrodepot_db;charset=utf8',"test","Test123456-+!");
$error = "";

$search = "name";
if(isset($_POST['search'])){  
    $search = $_POST['search'];
}
?>

<html lang="fr">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css" type="text/css">
    <link rel="stylesheet" href="styl.css" type="text/css">
    <title> - Comparateur datalayer / scrap - </title>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
</head>


<body>

    <div id="old_cont">
        <div id="menu_container">
            <ul id="menu">
                <li><a class="active" href="index.php"> - Comparateur Datalayer / Scrap - </a></li>
                <li><a class="active" href="vizualisation.php"> - Analyse Datalayer - </a></li>
                <li><a class="active" href="product_finder.php"> - Recherche de produit - </a></li>
            </ul>
        </div>
    </div>


    <div id="catch_attention">
        <h3>Pourcentage des produits dans le datalayer erronés</h3>
        <div id="catch_percent">
            <span id="percent">
        <?php 
            $issue = $db -> query('SELECT COUNT(DISTINCT products.ID) FROM products INNER JOIN datalayers ON (products.ID = datalayers.ID) WHERE products.name != datalayers.name OR products.price != datalayers.price OR products.brand != datalayers.brand OR products.category != datalayers.category OR products.reduction != datalayers.reduction');
            $total = $db -> query('SELECT COUNT(DISTINCT ID) FROM products');
            $issue = $issue -> fetch();
            $total = $total -> fetch();
            $result = number_format($issue[0]/$total[0]*100,2,',','');
            echo $result
        ?>
            %</span>
        </div>
    </div>




    <div class="container_item content_panel">
        <div class="select_key_datalayer">
            <label for="datalayer_select">Choississez une variable du datalayer</label>
            <form id="datalayer_selector" method="post"> 
                <select name="search" id="datalayer_select">
                    <option value="name">nom</option>
                    <option value="price">prix</option>
                    <option value="brand">marque</option>
                    <option value="category">category</option>
                    <option value="reduction">reduction</option>
                    <option value="variant">variant</option>
                    <option value="pageCategory">pageCategory</option>
                    <option value="pageSubCategory_1">pageSubCategory_1</option>
                    <option value="pageSubCategory_2">pageSubCategory_2</option>
                    <option value="pageSubCategory_3">pageSubCategory_3</option>
                    <option value="siteCountry">siteCountry</option>
                </select>
                <button onclick="myFunction()" type="submit" name="datalayer_sell" id="launch_it" value="select">Rechercher les url</button>
            </form>
        </div>
        <div class="good_item">
            <h3>URL sans probleme</h3>
            <div id="container_table">
            <table>
                <tr style="text-align:center">
                    <td>Lien du produit</td>
                    <td>Scraping</td>
                    <td>Dalayers</td>
                </tr>
            <?php
            $fetching_matching_products = $db -> query(sprintf("SELECT products.URL,products.ID,products.%s FROM products INNER JOIN datalayers ON(products.ID = datalayers.ID) WHERE products.%s = datalayers.%s",$search,$search,$search));           
            while($products = $fetching_matching_products -> fetch()){
                $fetch_test = $db -> query(sprintf("SELECT %s FROM datalayers WHERE ID = %s",$search,$products["ID"]));
                $fetch_test = $fetch_test -> fetch();
            ?>
                <div class="product_name">
                    <tr>
                        <?php echo '<td><a class="active_p" href= ',$products["URL"],'>Lien du produit</a></td>'?>
                        <!--<li><?php #echo print_r($products)?></li>-->
                        <td><?php echo $products[$search]?></td>
                        <td><?php echo $fetch_test[$search]?></td>
                    </tr>
                </div><p></p>
            <?php
            }?>
            </table>
            </div>
        </div>   
        <div class="bad_item">
            <h3>URL avec probleme</h3>
            <div id="container_table">
            <table>
                <tr style="text-align:center">
                    <td>Lien du produit</td>
                    <td>Scraping</td>
                    <td>Dalayers</td>
                </tr>
            <?php
            $fetching_matching_products = $db -> query(sprintf("SELECT products.URL,products.ID,products.%s FROM products INNER JOIN datalayers ON(products.ID = datalayers.ID) WHERE products.%s != datalayers.%s",$search,$search,$search));           
            while($products = $fetching_matching_products -> fetch()){
                $fetch_test = $db -> query(sprintf("SELECT %s FROM datalayers WHERE ID = %s",$search,$products["ID"]));
                $fetch_test = $fetch_test -> fetch();
            ?>
                <div class="product_name">
                    <tr>
                        <?php echo '<td><a class="active_p" href= ',$products["URL"],'>Lien du produit</a></td>'?>
                        <!--<li><?php #echo print_r($products)?></li>-->
                        <td><?php echo $products[$search]?></td>
                        <td><?php echo $fetch_test[$search]?></td>
                    </tr>
                </div><p></p>
            <?php
            }?>
            </table>
            </div>
        </div>
    </div>

    <div class="accordeon">
        <ul>
        <li>
        <p class="titre">Nom</p>
        <div>
        Votre contenu textuel...
        </div>
        </li>
        <li>
        <p class="titre">Prix</p>
        <div>
        Votre contenu textuel...
        </div>
        </li>
        <li>
        <p class="titre">Marque</p>
        <div>
        Votre contenu textuel...
        </div>
        </li>
        <li>
        <p class="titre">Category</p>
        <div>
        Votre contenu textuel...
        </div>
        </li>
        </ul>
    </div>

</body>   
<script>

    function myFunction(){
        document.getElementById("launch_it").submit();
    }


</script>
</html>